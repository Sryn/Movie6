﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MovieTheater
{
    public partial class Movie : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void hideAllPanel()
        {
            pnlAdd.Visible = false;
            pnlEdit.Visible = false;
        }

        protected void gvwMovie_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            hideAllPanel();

            if (e.CommandName == "EditComm")
            {
                pnlEdit.Visible = true;
            }

            if (e.CommandName == "DeleteComm")
            {

            }
        }

        protected void btnAdd_Click(object sender, EventArgs e)
        {
            hideAllPanel();
            tbxAddName.Text = "";
            tbxDuration.Text = "";
            tbxDescription.Text = "";
            tbxLanguage.Text = "";
            tbxSubtitle.Text = "";
            tbxRatings.Text = "";
            pnlAdd.Visible = true;
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {

        }

        protected void btnClose_Click(object sender, EventArgs e)
        {
            hideAllPanel();
        }

        
    }
}